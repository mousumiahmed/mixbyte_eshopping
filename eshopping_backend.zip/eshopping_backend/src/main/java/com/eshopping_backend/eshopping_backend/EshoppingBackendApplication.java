package com.eshopping_backend.eshopping_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EshoppingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EshoppingBackendApplication.class, args);
	}

}
